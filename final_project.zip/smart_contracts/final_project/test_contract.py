import unittest

from contract import Game


class TestGameContract(unittest.TestCase):

    def setUp(self):
        self.game = Game()
        self.game.register("user_account_1", "Alice")
        self.game.register("user_account_2", "Bob")
        self.game.fund_account("user_account_1", 1000)
        self.game.upsert_asset("Pokeball", "Attrape des Pokémon", 200)

    # Test enregistrement utilisateur
    def test_register_user(self):
        self.assertIsNotNone(self.game.users.get("user_account_1"))
        self.assertEqual(self.game.users.get("user_account_1").name, "Alice")

    # Test ajout de fonds
    def test_fund_account(self):
        self.game.fund_account("user_account_1", 500)
        self.assertEqual(self.game.users.get("user_account_1").balance, 1500)

    # Test création d'actif
    def test_upsert_asset(self):
        asset = self.game.assets.get("Pokeball")
        self.assertIsNotNone(asset)
        self.assertEqual(asset.price, 200)

    # Test achat d'actif
    def test_buy_asset(self):
        self.game.buy_asset("user_account_1", "Pokeball")
        user = self.game.users.get("user_account_1")
        self.assertEqual(user.inventory["Pokeball"], 1)
        self.assertEqual(user.balance, 800)

    # Test vente d'actif
    def test_sell_asset(self):
        self.game.buy_asset("user_account_1", "Pokeball")
        self.game.sell_asset("user_account_1", "Pokeball")
        user = self.game.users.get("user_account_1")
        self.assertEqual(user.balance, 900)
        self.assertEqual(user.inventory.get("Pokeball", 0), 0)

    # Test échange d'actif
    def test_trade_asset(self):
        self.game.buy_asset("user_account_1", "Pokeball")
        self.game.trade_assets("user_account_1", "user_account_2", "Pokeball")
        sender = self.game.users.get("user_account_1")
        receiver = self.game.users.get("user_account_2")
        self.assertEqual(sender.inventory.get("Pokeball", 0), 0)
        self.assertEqual(receiver.inventory["Pokeball"], 1)

    # Test vente d'actif sans stock
    def test_sell_without_asset(self):
        # Créer l'actif 'Potion' mais ne pas l'acheter
        self.game.upsert_asset("Potion", "Restaure 20 HP", 100)

        user = self.game.users.get("user_account_1")
        user.inventory = {}  # Forcer un inventaire vide

        with self.assertRaises(Exception) as context:
            self.game.sell_asset("user_account_1", "Potion")

        print(f"Exception levée : {context.exception}")

        self.assertTrue("Aucun actif à vendre" in str(context.exception))

    # Test achat sans fonds
    def test_buy_without_funds(self):
        self.game.fund_account("user_account_1", -900)
        with self.assertRaises(Exception) as context:
            self.game.buy_asset("user_account_1", "Pokeball")
        self.assertTrue("Fonds insuffisants" in str(context.exception))


if __name__ == "__main__":
    unittest.main()
