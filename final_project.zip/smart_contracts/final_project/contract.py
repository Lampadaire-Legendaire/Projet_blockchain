from datetime import datetime


class BoxMap:
    def __init__(self):
        self.store = {}

    def put(self, key, value):
        self.store[key] = value

    def get(self, key):
        return self.store.get(key, None)

    def delete(self, key):
        if key in self.store:
            del self.store[key]


# j'ai eu des problèmes à faire touner les mosules arc4, cette méthode à fonctionnée pour les utiliser
class ARC4Contract:
    def __init__(self):
        pass


class arc4:
    class Struct:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class UInt64(int):
        pass

    class String(str):
        pass


# structure utilisateur
class User(arc4.Struct):
    registered_at: arc4.UInt64
    name: arc4.String
    balance: arc4.UInt64
    inventory: dict


# structure des actifs
class GameAsset(arc4.Struct):
    name: arc4.String
    description: arc4.String
    price: arc4.UInt64


class Game(ARC4Contract):
    def __init__(self) -> None:
        self.users = BoxMap()
        self.assets = BoxMap()
        self.creator = "admin_account"

    # Enregistrer un utilisateur dans BoxMap
    def register(self, account: str, name: str):
        if self.users.get(account) is None:
            user = User(
                registered_at=arc4.UInt64(int(datetime.now().timestamp())),
                name=arc4.String(name),
                balance=arc4.UInt64(0),
                inventory={},
            )
            self.users.put(account, user)
            print(f"Utilisateur {name} enregistré.")
        else:
            print(f"Utilisateur {name} existe déjà.")

    # Ajouter des fonds à un utilisateur
    def fund_account(self, account: str, amount: int):
        user = self.users.get(account)
        if user:
            user.balance += arc4.UInt64(amount)
            self.users.put(account, user)
            print(f"Fonds ajoutés : {amount} microAlgos au compte de {user.name}")
        else:
            raise Exception("Utilisateur non enregistré")

    # Créer ou mettre à jour un actif
    def upsert_asset(self, asset_name: str, description: str, price: int):
        if self.creator != "admin_account":
            raise Exception("Seul l'administrateur peut ajouter des actifs.")

        asset = GameAsset(
            name=arc4.String(asset_name),
            description=arc4.String(description),
            price=arc4.UInt64(price),
        )
        self.assets.put(asset_name, asset)
        print(f"Actif '{asset_name}' ajouté ou mis à jour.")

    # Acheter un actif
    def buy_asset(self, account: str, asset_name: str):
        user = self.users.get(account)
        asset = self.assets.get(asset_name)

        if not user or not asset:
            raise Exception("Utilisateur ou actif non trouvé")

        if user.balance >= asset.price:
            user.balance -= asset.price
            user.inventory[asset_name] = user.inventory.get(asset_name, 0) + 1
            self.users.put(account, user)
            print(f"{user.name} a acheté {asset_name}. Nouveau solde : {user.balance}")
        else:
            raise Exception("Fonds insuffisants")

    # Revendre un actif
    def sell_asset(self, account: str, asset_name: str):
        user = self.users.get(account)
        asset = self.assets.get(asset_name)

        if not user or not asset:
            raise Exception("Utilisateur ou actif non trouvé")

        # Vérification si l'actif n'existe pas dans l'inventaire
        if (
            not user.inventory
            or asset_name not in user.inventory
            or user.inventory[asset_name] == 0
        ):
            raise Exception("Aucun actif à vendre")

        resale_value = int(asset.price * 0.5)
        user.balance += resale_value
        user.inventory[asset_name] -= 1
        if user.inventory[asset_name] == 0:
            del user.inventory[asset_name]

        self.users.put(account, user)
        print(f"{user.name} a vendu {asset_name} pour {resale_value} microAlgos.")

    # Echanger des actifs entre utilisateurs
    def trade_assets(self, sender: str, receiver: str, asset_name: str):
        sender_user = self.users.get(sender)
        receiver_user = self.users.get(receiver)

        if not sender_user or not receiver_user:
            raise Exception("L'un des utilisateurs n'est pas enregistré")

        if (
            asset_name not in sender_user.inventory
            or sender_user.inventory[asset_name] == 0
        ):
            raise Exception("L'actif n'est pas disponible pour l'échange")

        sender_user.inventory[asset_name] -= 1
        receiver_user.inventory[asset_name] = (
            receiver_user.inventory.get(asset_name, 0) + 1
        )

        self.users.put(sender, sender_user)
        self.users.put(receiver, receiver_user)
        print(f"{sender_user.name} a échangé {asset_name} avec {receiver_user.name}")
